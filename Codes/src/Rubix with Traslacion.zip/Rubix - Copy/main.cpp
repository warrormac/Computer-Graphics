#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <memory>
#include <vector>
#include <algorithm>
#include <random>
#include <map>


#include "Cubo.hpp"
#include "Camera.hpp"
#include "GameController.hpp"


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void ProcessInputMouse(GLFWwindow* window);
void key_callback(GLFWwindow* window, int key, int scancode, int action,
    int mods);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void AutomaticCamera();

// Create main controller of game
GameController game_controller(SCR_WIDTH, SCR_HEIGHT);





int main(int argc, char* argv[]) {

    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);


    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Cubito", NULL, NULL);

    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    glEnable(GL_DEPTH_TEST);

    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetKeyCallback(window, key_callback);


    // Init main controller of game
    game_controller.Init();


  

    while (!glfwWindowShouldClose(window)) {
        float currentFrame = static_cast<float>(glfwGetTime());
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // Camera automatic
        if (auto_camera) {
            projection = glm::perspective(glm::radians(camera.Zoom),
                (float)SCR_WIDTH / (float)SCR_HEIGHT,
                0.1f,
                100.0f);

            AutomaticCamera();
            view = camera.GetViewMatrix();

        }
        else {
            ProcessInputMouse(window);

            projection = glm::perspective(glm::radians(camera.Zoom),
                (float)SCR_WIDTH / (float)SCR_HEIGHT,
                0.1f,
                100.0f);
            view = camera.GetViewMatrix();
        }

        // God actions
        game_controller.ProcessInput(deltaTime);
        game_controller.UpdateMatrices(model, view, projection);
        game_controller.UpdateGame(deltaTime);

        // Render All
        glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        game_controller.Render();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action,
    int mode) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (game_controller.can_press) {
        if (key >= 0 && key < 1024)
            if (action == GLFW_PRESS)
                game_controller.keys_press[key] = true;
    }
    else {}

    if (action == GLFW_RELEASE) {
        game_controller.keys_press[key] = false;
        game_controller.keys_already_press[key] = false;
    }

    // Standard rubik's cube movements
    if (glfwGetKey(window, GLFW_KEY_RIGHT_SHIFT) == GLFW_PRESS ||
        glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) {
        if (glfwGetKey(window, GLFW_KEY_U) == GLFW_PRESS) {
            game_controller.U_PRIME_ANIM = true;
            game_controller.U_PRIME_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "U' ";
            velocity_cubito -= 0.1f;
        }

        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            game_controller.D_PRIME_ANIM = true;
            game_controller.D_PRIME_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "D' ";
            velocity_cubito -= 0.1f;
            far_of_cubito -= 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS) {
            game_controller.R_ANIM = true;
            game_controller.R_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "R' ";
            velocity_cubito -= 0.1f;
            far_of_cubito -= 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) {
            game_controller.L_PRIME_ANIM = true;
            game_controller.L_PRIME_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "L' ";
            velocity_cubito -= 0.1f;
            far_of_cubito -= 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            game_controller.F_PRIME_ANIM = true;
            game_controller.F_PRIME_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "F' ";
            velocity_cubito -= 0.1f;
            far_of_cubito -= 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS) {
            game_controller.B_ANIM = true;
            game_controller.B_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "B' ";
            velocity_cubito -= 0.1f;
            far_of_cubito -= 0.05f;
        }


        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
            game_controller.expand_contract_efect = false;
        }
    }
    else {
        if (glfwGetKey(window, GLFW_KEY_U) == GLFW_PRESS) {
            game_controller.U_ANIM = true;
            game_controller.U_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "U ";
            velocity_cubito += 0.1f;
            far_of_cubito += 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            game_controller.D_ANIM = true;
            game_controller.D_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "D ";
            velocity_cubito += 0.1f;
            far_of_cubito += 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS) {
            game_controller.R_PRIME_ANIM = true;
            game_controller.R_PRIME_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "R ";
            velocity_cubito += 0.1f;
            far_of_cubito += 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS) {
            game_controller.L_ANIM = true;
            game_controller.L_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "L ";
            velocity_cubito += 0.1f;
            far_of_cubito += 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) {
            game_controller.F_ANIM = true;
            game_controller.F_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "F ";
            velocity_cubito += 0.1f;
            far_of_cubito += 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS) {
            game_controller.B_PRIME_ANIM = true;
            game_controller.B_PRIME_ANIM_I = true;
            game_controller.some_movement = true;
            game_controller.str_scramble += "B ";
            velocity_cubito += 0.1f;
            far_of_cubito += 0.05f;
        }

        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            auto_camera = true;
        }

        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
            game_controller.expand_contract_efect = true;
        }


        if (glfwGetKey(window, GLFW_KEY_M) == GLFW_PRESS) {
            game_controller.ChangeFragCubito();
        }


    }

}

void ProcessInputMouse(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        camera.ProcessKeyboard(NightMoves::ADE, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        camera.ProcessKeyboard(NightMoves::ATA, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        camera.ProcessKeyboard(NightMoves::IZQ, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        camera.ProcessKeyboard(NightMoves::DER, deltaTime);

}

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    if (first_time_mouse) {
        lastX = static_cast<float>(xpos);
        lastY = static_cast<float>(ypos);
        first_time_mouse = false;
    }

    float xoffset = static_cast<float>(  lastX - xpos);
    float yoffset = static_cast<float>(ypos - lastY);
    lastX = static_cast<float>(xpos);
    lastY = static_cast<float>(ypos);

}


void AutomaticCamera() {
    float distance_from_cube = static_cast<float>(5.0f);
    float velocity_camera = static_cast<float>(glfwGetTime());
   
}