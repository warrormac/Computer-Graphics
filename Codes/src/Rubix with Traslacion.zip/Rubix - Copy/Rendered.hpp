#ifndef CUBITO_RENDERER_HPP
#define CUBITO_RENDERER_HPP

#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "Texture.hpp"
#include "Shader.h"
  
class Rendered {

 public:

  Rendered(const Shader &shader);
  ~Rendered();

 private:

  Shader shader;
  unsigned int quadVAO = -1;
};


Rendered::Rendered(const Shader &shader) {
    this->shader = shader;
}

Rendered::~Rendered() {
    glDeleteVertexArrays(1, &this->quadVAO);
}



  





#endif // CUBITO_RENDERER_HPP
