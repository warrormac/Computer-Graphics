#ifndef CUBITO_CAMERA_H
#define CUBITO_CAMERA_H

#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <vector>

enum class NightMoves { ADE, ATA, IZQ, DER };


class Camera {
private:

public:
    void actCam();

    glm::vec3 Pos;
    glm::vec3 Ad;
    glm::vec3 Up;
    glm::vec3 DER;
    glm::vec3 Ar;
    float Blink, Pitch, Velocidad, Sens, Zoom;

    Camera(glm::vec3 p = glm::vec3(0.0f, 0.0f, 0.0f),
        glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f),
        float B = -90.0f, float pitch = 0.0f);

    const glm::mat4 GetViewMatrix();
    void ProcessKeyboard(NightMoves, float);

};


Camera::Camera(glm::vec3 p, glm::vec3 up, float B, float pitch) : Ad(glm::vec3(0.0f, 0.0f, -1.0f)), Velocidad(0.5f), Sens(0.01f), Zoom(50.0f)
{
    Pos = p;
    Ar = up;
    Blink = B;
    Pitch = pitch;
    actCam();
}

const glm::mat4 Camera::GetViewMatrix()
{
    return glm::lookAt(Pos, Pos + Ad, Up);
}


void Camera::ProcessKeyboard(NightMoves direction, float deltaTime)
{
    float velocity = Velocidad * deltaTime;
    if (direction == NightMoves::ADE)
        Pos += Ar * (velocity * 15);
    if (direction == NightMoves::ATA)
        Pos -= Ar * (velocity * 15);
    if (direction == NightMoves::IZQ)
    {
        Pos -= DER * (velocity * 2);
    }
    if (direction == NightMoves::DER)
    {
        Pos += DER * (velocity * 2);
    }
}




void Camera::actCam() {
    glm::vec3 front;
    front.x = 1;
    front.y = 0;
    this->Ad = glm::normalize(front);
    this->DER = glm::normalize(glm::cross(this->Ad, this->Ar));
    this->Up = glm::normalize(glm::cross(this->DER, this->Ad));
}

#endif // CUBITO_CAMERA_H
