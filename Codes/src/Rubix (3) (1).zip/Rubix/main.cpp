#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <memory>
#include <vector>
#include <algorithm>
#include <random>
#include <map>


#include "Cubo.hpp"
#include "Camera.hpp"
#include "GameController.hpp"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void key_callback(GLFWwindow* window, int key, int scancode, int action,
    int mods);

const unsigned int SCR_WIDTH = 1000;
const unsigned int SCR_HEIGHT = 1000;
glm::mat4 model = glm::mat4(1.0f);
glm::mat4 view = glm::mat4(1.0f);
glm::mat4 projection = glm::mat4(1.0f);



float deltaTime = 0.0f;
float lastFrame = 0.0f;

// Create main controller of game
GameController game_controller(SCR_WIDTH, SCR_HEIGHT);

int main(int argc, char *argv[]) {

  glfwInit();
  glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
  glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
  glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

  GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Rubix Cube", NULL, NULL);

  //------------------------------------------------  Tester beg -------------------------------------

  if (window == NULL) {
    std::cout << "Failed to create GLFW window" << std::endl;
    glfwTerminate();
    return -1;
  }

  glfwMakeContextCurrent(window);
  glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

  if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
    std::cout << "Failed to initialize GLAD" << std::endl;
    return -1;
  }
  //------------------------------------------------  Tester end -------------------------------------

  //------------------------------------------------ Key input dect beg ----------------------------------
  glEnable(GL_DEPTH_TEST);


  glfwSetKeyCallback(window, key_callback);



  //------------------------------------------------ Key input dect end ----------------------------------
   
  // Init main controller of game
  game_controller.Init();



//-------------------------------------------------- main beg -------------------------------------------------
  while (!glfwWindowShouldClose(window)) {
    float currentFrame = static_cast<float>(glfwGetTime());
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;


    projection = glm::perspective(glm::radians(camera.Zoom),(float)SCR_WIDTH / (float)SCR_HEIGHT,0.1f,100.0f);
    view = camera.GetViewMatrix();
    

    // God actions
    game_controller.UpdateMatrices(model, view, projection);
                                                        
    // Render All
    glClearColor(1.0f, 1.0f, 0.05f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    game_controller.Render();

    glfwSwapBuffers(window);
    glfwPollEvents();
  }
 //-------------------------------------------------- main end -------------------------------------------------


  glfwTerminate();
  return 0;
}


//---------------------------------------------- Keys beg -----------------------------------
void key_callback(GLFWwindow* window, int key, int scancode, int action,
    int mode) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (game_controller.can_press) {
        if (key >= 0 && key < 1024)
            if (action == GLFW_PRESS)
                game_controller.keys_press[key] = true;
    }
    else {}

    if (action == GLFW_RELEASE) {
        game_controller.keys_press[key] = false;
        game_controller.keys_already_press[key] = false;
    }

    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement::FORWARD, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement::BACKWARD, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement::LEFT, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        camera.ProcessKeyboard(CameraMovement::RIGHT, deltaTime);
        
    
}


void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}




