#ifndef CUBITO_GAME_CONTROLLER_HPP
#define CUBITO_GAME_CONTROLLER_HPP

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <algorithm>
#include <iostream>
#include <tuple>
#include <sstream>
#include <vector>
#include <string>


#include "Resources.hpp"



enum class Move {
    L, R, U, D, F, B
};

Camera camera(glm::vec3(0.0f, 0.0f, 5.0f)); // initial position of camera


class GameController {

public:

    // COntructor and destructor
    GameController(unsigned int, unsigned int);
    ~GameController();

    // Things on game
    Rendered* Renderer = nullptr;
    Cubo rubick_cube;
    const float distance_b_cubes = 0.45f;

    // General variables of game_controller
    unsigned int width = 0;
    unsigned int height = 0;
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 view = glm::mat4(1.0f);
    glm::mat4 projection = glm::mat4(1.0f);

    // Variables that control key press
    bool can_press = true;
    bool some_movement = false;
    bool keys_press[1024]{ false };
    bool keys_already_press[1024]{ false };

    // reflect
    unsigned int cube_map_night = -1;
    unsigned int cube_map_ocean = -1;

    // Functions of game
    void Init();
    void Render();
    void UpdateMatrices(glm::mat4, glm::mat4, glm::mat4);


};


GameController::GameController(unsigned int width, unsigned int height)
    : keys_press(),
    keys_already_press(),
    width(width),
    height(height) {
}

GameController::~GameController() {
    delete Renderer;


}

void GameController::Init() {

   

    // Loading textures
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/green.png", true, "negro");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yellow");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "red");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "white");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "blue");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "orange");

    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL2");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL3");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL4");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL5");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL6");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL7");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL8");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/blue.png", true, "AZUL9");

    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi1");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi2");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi3");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi4");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi5");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi6");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi7");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi8");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/amarillo.png", true, "yi9");

    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO1");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO2");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO3");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO4");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO5");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO6");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO7");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO8");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/white.png", true, "BLANCO9");

    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO1");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO2");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO3");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO4");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO5");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO6");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO7");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO8");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/red.png", true, "ROJO9");


    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og1");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og2");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og3");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og4");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og5");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og6");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og7");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og8");
    Resources::LoadTexture("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/images/naranja.png", true, "og9");

    Resources::LoadShader("C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/shaders/cubito.vs", "C:/Users/Andre/OneDrive/UCSP/Semestre 4 Online/Grafica/prueba/GLFW_GLAD_GLUT_GLEW_cmake_project/src/cubito/src/shaders/cubito.fs", nullptr, "cubito");


    // Create main Rendered
    this->Renderer = new Rendered(Resources::GetShader("cubito"));

    {
        this->rubick_cube.cubitos[3] = std::make_shared<Cubito>(
            Resources::GetTexture("red"),
            Resources::GetTexture("AZUL"),
            Resources::GetTexture("ROJO3"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, distance_b_cubes, -distance_b_cubes), 3);
        this->rubick_cube.cubitos[6] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO2"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, distance_b_cubes, -distance_b_cubes), 6);
        this->rubick_cube.cubitos[9] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO1"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("yi3"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, distance_b_cubes, -distance_b_cubes), 9);
        this->rubick_cube.cubitos[12] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO6"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, 0.0f, -distance_b_cubes), 12);
        this->rubick_cube.cubitos[15] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO5"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, 0.0f, -distance_b_cubes), 15);
        this->rubick_cube.cubitos[18] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO4"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, 0.0f, -distance_b_cubes), 18);
        this->rubick_cube.cubitos[21] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO9"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, -distance_b_cubes, -distance_b_cubes), 21);
        this->rubick_cube.cubitos[24] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO8"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, -distance_b_cubes, -distance_b_cubes), 24);
        this->rubick_cube.cubitos[27] = std::make_shared<Cubito>(
            Resources::GetTexture("ROJO7"),
            Resources::GetTexture("og1"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, -distance_b_cubes, -distance_b_cubes), 27);

        this->rubick_cube.cubitos[2] = std::make_shared<Cubito>(
            Resources::GetTexture("red"),
            Resources::GetTexture("AZUL2"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, distance_b_cubes, 0.0f), 2);
        this->rubick_cube.cubitos[5] = std::make_shared<Cubito>(
            Resources::GetTexture("red"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, distance_b_cubes, 0.0f), 5);
        this->rubick_cube.cubitos[8] = std::make_shared<Cubito>(
            Resources::GetTexture("red"),
            Resources::GetTexture("yi2"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, distance_b_cubes, 0.0f), 8);
        this->rubick_cube.cubitos[11] = std::make_shared<Cubito>(
            Resources::GetTexture("AZUL5"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, 0.0f, 0.0f), 11);
        this->rubick_cube.cubitos[14] = std::make_shared<Cubito>(
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, 0.0f, 0.0f), 14);
        this->rubick_cube.cubitos[17] = std::make_shared<Cubito>(
            Resources::GetTexture("yi5"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, 0.0f, 0.0f), 17);
        this->rubick_cube.cubitos[20] = std::make_shared<Cubito>(
            Resources::GetTexture("AZUL8"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, -distance_b_cubes, 0.0f), 20);
        this->rubick_cube.cubitos[23] = std::make_shared<Cubito>(
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, -distance_b_cubes, 0.0f), 23);
        this->rubick_cube.cubitos[26] = std::make_shared<Cubito>(
            Resources::GetTexture("yi8"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, -distance_b_cubes, 0.0f), 26);

        this->rubick_cube.cubitos[1] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO1"),
            Resources::GetTexture("AZUL3"),
            Resources::GetTexture("red"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, distance_b_cubes, distance_b_cubes), 1);
        this->rubick_cube.cubitos[4] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO2"),
            Resources::GetTexture("red"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, distance_b_cubes, distance_b_cubes), 4);
        this->rubick_cube.cubitos[7] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO3"),
            Resources::GetTexture("red"),
            Resources::GetTexture("yi1"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, distance_b_cubes, distance_b_cubes), 7);
        this->rubick_cube.cubitos[10] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO4"),
            Resources::GetTexture("AZUL6"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, 0.0f, distance_b_cubes), 10);
        this->rubick_cube.cubitos[13] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO5"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, 0.0f, distance_b_cubes), 13);
        this->rubick_cube.cubitos[16] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO6"),
            Resources::GetTexture("yi4"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, 0.0f, distance_b_cubes), 16);
        this->rubick_cube.cubitos[19] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO7"),
            Resources::GetTexture("AZUL9"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(-distance_b_cubes, -distance_b_cubes, distance_b_cubes), 19);
        this->rubick_cube.cubitos[22] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO8"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(0.0f, -distance_b_cubes, distance_b_cubes), 22);
        this->rubick_cube.cubitos[25] = std::make_shared<Cubito>(
            Resources::GetTexture("BLANCO9"),
            Resources::GetTexture("yi7"),
            Resources::GetTexture("orange"),
            Resources::GetTexture("negro"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            Resources::GetShader("cubito"),
            glm::vec3(distance_b_cubes, -distance_b_cubes, distance_b_cubes), 25);
    }
}


void GameController::Render() {
    // Render rubick_cube
    rubick_cube.Draw(*Renderer,
        this->model,
        this->view,
        this->projection,
        camera.Position,
        this->cube_map_night,
        this->cube_map_ocean,
        false);
    
}


void GameController::UpdateMatrices(glm::mat4 new_model,
    glm::mat4 new_view,
    glm::mat4 new_proyection) {
    this->model = new_model;
    this->view = new_view;
    this->projection = new_proyection;
}


#endif // CUBITO_GAME_CONTROLLER_HPP
